module.exports = {
    secret: 'secretsauce',
    database: 'mongodb+srv://lacanism:8MuE4AihxtBlnTLK@cluster0.7dxks.mongodb.net/auth_data?retryWrites=true&w=majority'
}
