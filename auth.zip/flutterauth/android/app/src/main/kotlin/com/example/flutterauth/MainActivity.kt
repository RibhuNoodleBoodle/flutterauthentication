package com.example.flutterauth

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
