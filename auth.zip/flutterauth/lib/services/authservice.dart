import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import '../screens/loginscreen.dart';
class AuthService{
    Dio dio = Dio();

    login(name, password) async {
        try{
            return await dio.post(
                'https://flutter-authentication-project.herokuapp.com/authenticate', 
                data: {"name": name, "password": password}, 
                options: Options(contentType: Headers.formUrlEncodedContentType));
        }on DioError catch(e){
                    };
    }
}